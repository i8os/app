import android.widget.Toast;
import com.tencent.util.QQToastUtil;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;
import java.util.Base64;
import java.net.URLEncoder;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
public static void delAllFile(File directory, int type){
if (directory==null||!directory.exists()) return;
if (!directory.isDirectory()){
directory.delete();
return;
}
File[] files=directory.listFiles();
if (files!=null){
for (File file:files){
delAllFile(file, type);
}
}
if (type==0){
directory.delete();
}
}
delAllFile(new File(pluginPath+"pluginConfig/"),0);
String 免费主题链接="https://zb.vip.qq.com/mall/item-detail?appid=3&itemid=2105";
String 主题="/data/user/0/com.tencent.mobileqq/app_theme_810/";
public QQToastUtil QToastUtil=new QQToastUtil();
Activity activity=getNowActivity();
public String getLastFolderName(String directoryPath){
File directory=new File(directoryPath);
if (!directory.exists()||!directory.isDirectory()) return "";
File[] files=directory.listFiles();
if (files==null) return "";
String lastFolder="";
for (File file:files){
if (file.isDirectory()) lastFolder=file.getName();
}
return lastFolder;
}

public String getFirstSubFolder(String directoryPath){
File dir=new File(directoryPath);
if (!dir.exists()||!dir.isDirectory()) return "";
File[] files=dir.listFiles();
if (files==null) return "";
for (File file:files){
if (file.isDirectory()) return file.getName();
}
return "";
}

public static void clearDirectoryContents(String path) throws IOException{
File directory=new File(path);
if (directory.exists()&&directory.isDirectory()){
File[] files=directory.listFiles();
if (files != null){
for (File file:files){
if (file.isDirectory()){
clearDirectoryContents(file.getAbsolutePath());
file.delete();
}else{
file.delete();
}
}
}
}
}

public static void moveDirectoryContents(String source, String destination) throws IOException{
File sourceDirectory=new File(source);
File destinationDirectory=new File(destination);
if (sourceDirectory.exists()&&sourceDirectory.isDirectory()){
File[] files=sourceDirectory.listFiles();
if (files != null){
for (File file:files){
File dest=new File(destinationDirectory, file.getName());
if (file.isDirectory()){
dest.mkdir();
moveDirectoryContents(file.getAbsolutePath(), dest.getAbsolutePath());
}else{
file.renameTo(dest);
}
}
}
}
}

public static void copyDirectoryContents(String source, String destination) throws IOException{
File sourceDirectory=new File(source);
File destinationDirectory=new File(destination);
if (sourceDirectory.exists()&&sourceDirectory.isDirectory()){
File[] files=sourceDirectory.listFiles();
if (files != null){
for (File file:files){
File dest=new File(destinationDirectory, file.getName());
if (file.isDirectory()){
dest.mkdir();
copyDirectoryContents(file.getAbsolutePath(), dest.getAbsolutePath());
}else{
copyFile(file, dest);
}
}
}
}
}

public static void copyFile(File source, File destination) throws IOException{
if (!destination.getParentFile().exists()){
destination.getParentFile().mkdirs();
}
if (destination.exists()){
destination.delete();
}
destination.createNewFile();
InputStream in=new FileInputStream(source);
OutputStream out=new FileOutputStream(destination);
byte[] buffer=new byte[1024];
int length;
while ((length=in.read(buffer))>0){
out.write(buffer, 0, length);
}
in.close();
out.close();
}

public boolean 移动至路径(String sourcePath, String destinationPath){
File sourceFile=new File(sourcePath);
File destinationFile=new File(destinationPath);
if (!sourceFile.exists()||!sourceFile.isFile()){
return false;
}
File parentDir=destinationFile.getParentFile();
if (parentDir != null&&!parentDir.exists()){
parentDir.mkdirs();
}
if (destinationFile.exists()){
destinationFile.delete();
}
boolean renamed=sourceFile.renameTo(destinationFile);
if (!renamed){
InputStream in=null;
OutputStream out=null;
try{
in=new FileInputStream(sourceFile);
out=new FileOutputStream(destinationFile);
byte[] buffer=new byte[1024];
int length;
while ((length=in.read(buffer))>0){
out.write(buffer, 0, length);
}
sourceFile.delete();
return true;
}catch(IOException e){
return false;
}finally{
if (in != null){
try{
in.close();
}catch(IOException e){
}
}
if (out != null){
try{
out.close();
}catch(IOException e){
}
}
}
}
return true;
}

public void 写(String Path, String WriteData){
FileOutputStream fos=null;
try{
File file=new File(Path);
if (!file.exists()){
file.createNewFile();
}
fos=new FileOutputStream(file);
byte[] bytesArray=WriteData.getBytes();
fos.write(bytesArray);
fos.flush();
}catch(IOException e){
}finally{
if (fos != null){
try{
fos.close();
}catch(IOException e){
}
}
}
}

public void QQToast(String text, int i){
QToastUtil.showQQToastInUiThread(i, text);
}

public void UI(AlertDialog dialog){
GradientDrawable gradientDrawable=new GradientDrawable();
gradientDrawable.setColor(Color.parseColor("#aaBEE7"));
gradientDrawable.setCornerRadius(50);
if (Build.VERSION.SDK_INT>=Build.VERSION_CODES.LOLLIPOP){
dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
dialog.getWindow().setDimAmount(0.2f);
}else{
dialog.getWindow().setBackgroundDrawable(gradientDrawable);
}
WindowManager.LayoutParams params=dialog.getWindow().getAttributes();
params.alpha=0.9f;
dialog.getWindow().setAttributes(params);
dialog.setOnShowListener(new DialogInterface.OnShowListener(){
public void onShow(DialogInterface dialogInterface){
dialog.getButton(DialogInterface.BUTTON_NEGATIVE).setTextColor(Color.parseColor("#123456"));
}
});
}

public Activity getActivity(){
return getNowActivity();
}

public void theme(int type, String qun, String name){
showCustomThemeIdDialog();
}

public String extractThemeIdFromInput(String input){
if (input.isEmpty()) return "";
Pattern pattern=Pattern.compile("item(?:_)?id=(\\d+)");
Matcher matcher=pattern.matcher(input);
if (matcher.find()){
return matcher.group(1);
}
if (input.matches("\\d+")){
return input;
}
return "";
}

public void openFreeTheme(){
String url=免费主题链接;
String base=Base64.getEncoder().encodeToString(url.getBytes());
String newUrl="mqqapi://forward/url?url_prefix="+URLEncoder.encode(base);
Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(newUrl));
intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
getActivity().startActivity(intent);
QQToast("正在打开,请稍候...",2);
}

addItem("主题设置", "theme");
public void showCustomThemeIdDialog(){
Activity activity=getActivity();
activity.runOnUiThread(new Runnable(){
public void run(){
AlertDialog.Builder builder=new AlertDialog.Builder(activity, AlertDialog.THEME_DEVICE_DEFAULT_LIGHT);
builder.setTitle("主题重定向");
LinearLayout container=new LinearLayout(activity);
container.setOrientation(LinearLayout.VERTICAL);
container.setPadding(20, 20, 20, 20);
LinearLayout topBtnBar=new LinearLayout(activity);
topBtnBar.setOrientation(LinearLayout.HORIZONTAL);
topBtnBar.setGravity(Gravity.RIGHT);
topBtnBar.setPadding(0,0,0,10);
TextView updateBtn=new TextView(activity);
updateBtn.setText("更新主题");
updateBtn.setTextColor(Color.parseColor("#123456"));
updateBtn.setTextSize(14);
updateBtn.setPadding(10,5,10,5);
updateBtn.setOnClickListener(new View.OnClickListener(){
public void onClick(View v){
final String folderName=getLastFolderName(主题);
QQToast("请稍候...",2);
new Thread(new Runnable(){
public void run(){
String ztName="2105";
String 源1="/data/user/0/com.tencent.mobileqq/app_theme_810/"+ztName+"/theme."+ztName+"/";
String 源2="/data/user/0/com.tencent.mobileqq/app_theme_810/"+ztName+"/theme."+ztName+".zip";
String 源3="/data/user/0/com.tencent.mobileqq/app_theme_810/"+ztName+"/theme."+folderName+".zip";
String lj1="/data/user/0/com.tencent.mobileqq/app_theme_810/"+folderName+"/theme."+folderName+"/";
String lj2="/data/user/0/com.tencent.mobileqq/app_theme_810/"+folderName+"/theme."+folderName+".zip";
String folder1=getFirstSubFolder(lj1);
String folder源=getFirstSubFolder(源1);
String source=源1+folder源+"/";
String dest=lj1+folder1+"/";
try{
clearDirectoryContents(source);
}catch(IOException e){
}
移动至路径(lj2, 源2);
try{
copyDirectoryContents(dest, source);
moveDirectoryContents(lj2, 源3);
}catch(IOException e){
}
activity.runOnUiThread(new Runnable(){
public void run(){
if (!folderName.equals(ztName)){
QQToast("更新成功,请重启QQ",2);
}
}
});
}
}).start();
}
});
TextView clearBtn=new TextView(activity);
clearBtn.setText("清空主题");
clearBtn.setTextColor(Color.parseColor("#123456"));
clearBtn.setTextSize(14);
clearBtn.setPadding(10,5,10,5);
clearBtn.setOnClickListener(new View.OnClickListener(){
public void onClick(View v){
clearDirectoryContents(主题);
QQToast("已清空,请重启QQ2次",2);
}
});
topBtnBar.addView(updateBtn);
topBtnBar.addView(clearBtn);
container.addView(topBtnBar);
TextView textPrompt=new TextView(activity);
textPrompt.setText("输入主题 Item ID");
textPrompt.setTextColor(Color.parseColor("#333333"));
container.addView(textPrompt);
final EditText editText=new EditText(activity);
container.addView(editText);
builder.setView(container);
builder.setPositiveButton("确定", new DialogInterface.OnClickListener(){
public void onClick(DialogInterface dialog,int which){
String input=editText.getText().toString().trim();
if (input.isEmpty()){
QQToast("为空,请重新输入",2);
dialog.dismiss();
return;
}
String themeId=extractThemeIdFromInput(input);
if (themeId.isEmpty()){
QQToast("格式错误,请重新输入",2);
return;
}
String url="https://zb.vip.qq.com/mall/item-detail?appid=3&itemid="+themeId;
String base=Base64.getEncoder().encodeToString(url.getBytes());
String newUrl="mqqapi://forward/url?url_prefix="+URLEncoder.encode(base);
Intent intent=new Intent(Intent.ACTION_VIEW, Uri.parse(newUrl));
intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
activity.startActivity(intent);
QQToast("正在打开,请稍候...",2);
dialog.dismiss();
}
});
builder.setNegativeButton("关闭", new DialogInterface.OnClickListener(){
public void onClick(DialogInterface dialog,int which){
dialog.cancel();
}
});
builder.setNeutralButton("免费主题", new DialogInterface.OnClickListener(){
public void onClick(DialogInterface dialog,int which){
openFreeTheme();
dialog.dismiss();
}
});
AlertDialog dialog=builder.create();
UI(dialog);
dialog.show();
dialog.getButton(DialogInterface.BUTTON_NEUTRAL).setTextColor(Color.parseColor("#123456"));
}
});
}